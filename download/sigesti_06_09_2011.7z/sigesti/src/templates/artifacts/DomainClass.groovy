@artifact.package@class @artifact.name@ {

    static constraints = {
    }
}
