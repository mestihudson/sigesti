@artifact.package@class @artifact.name@ {

    def filters = {
        all(controller:'*', action:'*') {
            before = {
                
            }
            after = {
                
            }
            afterView = {
                
            }
        }
    }
    
}
